package com.seveneast.smscontroller;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Talks to the controller over its own Wi-Fi network using plain HTTP.
 * The request path is a template in which {cmd} is replaced by the (URL-encoded) command text.
 * Callbacks arrive on a background thread.
 */
public final class WifiApi {
    public interface Callback {
        void onResult(boolean ok, String body, String error);
    }

    public static final String DEFAULT_IP = "192.168.4.1";
    public static final String DEFAULT_TEMPLATE = "/cmd?text={cmd}";

    private static final ExecutorService POOL = Executors.newSingleThreadExecutor();

    private WifiApi() { }

    /** Finds the phone's Wi-Fi network so the request is sent through it even if it has no internet. */
    private static Network findWifi(Context ctx) {
        try {
            ConnectivityManager cm = (ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return null;
            for (Network n : cm.getAllNetworks()) {
                NetworkCapabilities caps = cm.getNetworkCapabilities(n);
                if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return n;
            }
        } catch (RuntimeException ignored) { }
        return null;
    }

    private static HttpURLConnection open(Context ctx, URL url) throws java.io.IOException {
        Network wifi = findWifi(ctx);
        return (HttpURLConnection) (wifi != null ? wifi.openConnection(url) : url.openConnection());
    }

    private static String read(InputStream in) throws java.io.IOException {
        if (in == null) return "";
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[1024];
            int n;
            while ((n = in.read(buf)) > 0 && out.size() < 8192) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } finally {
            try { in.close(); } catch (java.io.IOException ignored) { }
        }
    }

    /** Sends one command. ok = the controller answered with a 2xx status. */
    public static void request(final Context ctx, final String ip, final String template,
                               final String command, final Callback cb) {
        POOL.execute(() -> {
            HttpURLConnection con = null;
            try {
                String path = template.replace("{cmd}", URLEncoder.encode(command, "UTF-8"));
                if (!path.startsWith("/")) path = "/" + path;
                con = open(ctx, new URL("http://" + ip + path));
                con.setConnectTimeout(4000);
                con.setReadTimeout(8000);
                con.setRequestMethod("GET");
                int code = con.getResponseCode();
                String body = read(code >= 400 ? con.getErrorStream() : con.getInputStream());
                if (code >= 200 && code < 300) cb.onResult(true, body, null);
                else cb.onResult(false, body, "HTTP " + code);
            } catch (Exception ex) {
                cb.onResult(false, null, ex.getClass().getSimpleName());
            } finally {
                if (con != null) con.disconnect();
            }
        });
    }

    /** Connection test: ok = the controller answered anything at all. */
    public static void ping(final Context ctx, final String ip, final Callback cb) {
        POOL.execute(() -> {
            HttpURLConnection con = null;
            try {
                con = open(ctx, new URL("http://" + ip + "/"));
                con.setConnectTimeout(2500);
                con.setReadTimeout(3000);
                con.setRequestMethod("GET");
                int code = con.getResponseCode();
                cb.onResult(true, null, "HTTP " + code);
            } catch (Exception ex) {
                cb.onResult(false, null, ex.getClass().getSimpleName());
            } finally {
                if (con != null) con.disconnect();
            }
        });
    }
}
