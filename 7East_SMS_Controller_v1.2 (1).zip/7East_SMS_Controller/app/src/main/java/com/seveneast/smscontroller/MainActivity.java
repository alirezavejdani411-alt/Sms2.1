package com.seveneast.smscontroller;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.text.InputType;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 7East controller app. Controls the relays by SMS (from anywhere) or over the controller's Wi-Fi (nearby).
 * Names and settings are stored only on this phone. Live status changes only after a reply from the controller.
 */
public class MainActivity extends Activity {
    private static final int MAX_COILS = 40;
    private static final int MAX_REGS = 20;
    private static final int REQUEST_SMS_PERMISSIONS = 710;
    private static final int REQUEST_PHONE_STATE = 711;
    private static final long SMS_TIMEOUT_MS = 90_000L;
    private static final long WIFI_TIMEOUT_MS = 15_000L;
    private static final String ACTION_INCOMING = SmsReceiver.ACTION_INCOMING;
    private static final String ACTION_SENT_RESULT = SmsSentReceiver.ACTION_SENT_RESULT;

    private static final int BG = Color.rgb(11, 17, 32);
    private static final int CARD = Color.rgb(24, 35, 56);
    private static final int CARD_DARK = Color.rgb(15, 25, 43);
    private static final int BORDER = Color.rgb(47, 65, 91);
    private static final int TEXT = Color.rgb(235, 242, 252);
    private static final int MUTED = Color.rgb(157, 174, 197);
    private static final int BLUE = Color.rgb(14, 165, 233);
    private static final int GREEN = Color.rgb(16, 185, 129);
    private static final int RED = Color.rgb(239, 68, 68);
    private static final int AMBER = Color.rgb(245, 158, 11);
    private static final int PURPLE = Color.rgb(139, 92, 246);

    // Main tabs (shown in the strip under the top bar) and pages (opened from the ☰ menu)
    private static final int TAB_SMS = 0;
    private static final int TAB_WIFI = 1;
    private static final int TAB_REGS = 2;
    private static final int PAGE_ADMIN = 3;
    private static final int PAGE_SETTINGS = 4;
    private static final int PAGE_ABOUT = 5;

    // Command tracker phases
    private static final int PH_SENDING = 0;
    private static final int PH_WAITING = 1;
    private static final int PH_OK = 2;
    private static final int PH_ERR = 3;
    private static final int PH_TIMEOUT = 4;

    private SharedPreferences prefs;
    private SharedPreferences smsStore;
    private final Handler handler = new Handler(Looper.getMainLooper());

    // -1 = unknown; 0 = OFF; 1 = ON; 2 = PULSE
    private final int[] coilState = new int[MAX_COILS];
    private final int[] regValue = new int[MAX_REGS];
    private final boolean[] regKnown = new boolean[MAX_REGS];
    private final String[] coilNames = new String[MAX_COILS];
    private final String[] regNames = new String[MAX_REGS];

    private int currentTab = TAB_SMS;
    private int lastMainTab = TAB_SMS;
    private int lastBuiltTab = -1;
    private String stateMessage = "برای دریافت وضعیت، دکمهٔ ↻ بالای صفحه را بزنید.";
    private String lastReply = "";

    // Wi-Fi link state: 0 = unknown/checking, 1 = reachable, 2 = not reachable
    private int wifiState = 0;
    private boolean wifiChecking = false;

    // Transaction state
    private boolean waiting = false;
    private boolean txWifi = false;
    private String expectedType = "";
    private int expectedIndex = -1;
    private String pendingCommand = "";
    private String pendingAdminPhone = "";
    private long activeToken = 0L;
    private long tokenCounter = System.currentTimeMillis();

    // Command tracker (status sheet) state
    private int cmdPhase = PH_OK;
    private String cmdTitle = "";
    private String cmdCode = "";
    private String cmdNote = "";
    private String cmdResult = "";
    private String cmdReply = "";
    private boolean cmdSmsSent = false;
    private boolean cmdGotReply = false;
    private long cmdPhaseStart = 0L;

    // Frame views
    private LinearLayout root;
    private TextView statusChip;
    private TextView stateView;
    private Button refreshBtn;
    private Button menuBtn;
    private LinearLayout tabsRow;
    private ScrollView scroll;
    private LinearLayout contentHost;
    private EditText deviceNumberInput;
    private EditText wifiIpInput;
    private EditText wifiTplInput;
    private BroadcastReceiver internalReceiver;

    // Tracker sheet views
    private Dialog sheet;
    private TextView shTitle;
    private TextView shCode;
    private TextView shDetail;
    private TextView shReply;
    private TextView shTimer;
    private ProgressBar shBar;
    private Button shClose;
    private Button shAction;
    private final TextView[] shIcon = new TextView[3];
    private final TextView[] shLabel = new TextView[3];

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            updateSheet();
            if (waiting) handler.postDelayed(this, 1000L);
        }
    };

    // ---------------------------------------------------------------- lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(Color.rgb(7, 12, 24));
        prefs = getSharedPreferences("local_settings", MODE_PRIVATE);
        smsStore = getSharedPreferences(SmsReceiver.STORE, MODE_PRIVATE);
        Arrays.fill(coilState, -1);
        loadNames();
        lastReply = prefs.getString("last_reply", "");
        if (normalizePhone(deviceNumber()).length() < 10) {
            currentTab = PAGE_SETTINGS;
            stateMessage = "ابتدا شمارهٔ سیم‌کارت کنترلر را در تنظیمات وارد کنید.";
        }
        buildFrame();
        render(true);
        ensureSmsPermissions();
    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_INCOMING);
        filter.addAction(ACTION_SENT_RESULT);
        internalReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                if (intent == null) return;
                if (ACTION_INCOMING.equals(intent.getAction())) {
                    handleIncomingOnce(intent.getStringExtra("sender"), intent.getStringExtra("body"), intent.getLongExtra("id", 0L));
                } else if (ACTION_SENT_RESULT.equals(intent.getAction())) {
                    long token = intent.getLongExtra("token", -1L);
                    boolean success = intent.getBooleanExtra("success", false);
                    if (waiting && !txWifi && token == activeToken) {
                        if (success) {
                            cmdSmsSent = true;
                            if (cmdPhase == PH_SENDING) cmdPhase = PH_WAITING;
                            updateSheet();
                        } else {
                            endTransaction(PH_ERR, "ارسال پیامک انجام نشد؛ اعتبار، آنتن یا سیم‌کارت را بررسی کنید.");
                        }
                    }
                }
            }
        };
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(internalReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(internalReceiver, filter);
        processStoredSmsIfNew();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (currentTab == TAB_WIFI) checkWifi();
        render(true);
    }

    @Override
    protected void onStop() {
        if (internalReceiver != null) {
            try { unregisterReceiver(internalReceiver); } catch (IllegalArgumentException ignored) { }
            internalReceiver = null;
        }
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(ticker);
        if (sheet != null && sheet.isShowing()) {
            try { sheet.dismiss(); } catch (RuntimeException ignored) { }
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (!isMainTab(currentTab)) {
            currentTab = lastMainTab;
            render(true);
        } else {
            super.onBackPressed();
        }
    }

    // ---------------------------------------------------------------- permissions & stored settings

    private void ensureSmsPermissions() {
        if (Build.VERSION.SDK_INT < 23) return;
        boolean send = checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
        boolean receive = checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED;
        if (!send || !receive) {
            requestPermissions(new String[]{Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS}, REQUEST_SMS_PERMISSIONS);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean ok = grantResults.length > 0;
        for (int result : grantResults) if (result != PackageManager.PERMISSION_GRANTED) ok = false;
        if (requestCode == REQUEST_SMS_PERMISSIONS) {
            stateMessage = ok ? "مجوز پیامک فعال شد." : "برای ارسال و دریافت پیامک، مجوز پیامک را فعال کنید (تنظیمات ← مجوز پیامک).";
            render(true);
        } else if (requestCode == REQUEST_PHONE_STATE) {
            stateMessage = ok ? "سیم‌کارت‌های گوشی شناسایی شد." : "بدون این مجوز نمی‌توان سیم‌کارت‌ها را فهرست کرد.";
            render(true);
        }
    }

    private boolean hasSmsPermissions() {
        return Build.VERSION.SDK_INT < 23 ||
                (checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED &&
                 checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED);
    }

    private boolean hasPhoneStatePermission() {
        return Build.VERSION.SDK_INT < 23 ||
                checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED;
    }

    private void loadNames() {
        for (int i = 0; i < MAX_COILS; i++) coilNames[i] = prefs.getString("coil_name_" + i, "رله " + (i + 1));
        for (int i = 0; i < MAX_REGS; i++) regNames[i] = prefs.getString("reg_name_" + i, "رجیستر " + (i + 1));
    }

    private String deviceNumber() { return prefs.getString("device_number", "").trim(); }

    private int activeCoils() { return Math.max(1, Math.min(MAX_COILS, prefs.getInt("active_coils", MAX_COILS))); }

    private void setActiveCoils(int n) {
        prefs.edit().putInt("active_coils", Math.max(1, Math.min(MAX_COILS, n))).apply();
        render(true);
    }

    private boolean regsEnabled() { return prefs.getBoolean("regs_enabled", true); }
    private boolean wifiEnabled() { return prefs.getBoolean("wifi_enabled", true); }
    private boolean isAdmin() { return prefs.getBoolean("is_admin", true); }
    private boolean techDetails() { return prefs.getBoolean("tech_details", false); }
    private boolean relayIsPulse(int i) { return prefs.getBoolean("relay_pulse_" + i, false); }
    private String wifiIp() { return prefs.getString("wifi_ip", WifiApi.DEFAULT_IP).trim(); }
    private String wifiTemplate() { return prefs.getString("wifi_template", WifiApi.DEFAULT_TEMPLATE).trim(); }
    private int simSubId() { return prefs.getInt("sim_sub_id", -1); }

    private boolean isMainTab(int tab) { return tab == TAB_SMS || tab == TAB_WIFI || tab == TAB_REGS; }

    /** Moves off a tab or page that the settings have switched off. */
    private void normalizeTab() {
        if (currentTab == TAB_WIFI && !wifiEnabled()) currentTab = TAB_SMS;
        if (currentTab == TAB_REGS && !regsEnabled()) currentTab = TAB_SMS;
        if (currentTab == PAGE_ADMIN && !isAdmin()) currentTab = TAB_SMS;
        if (isMainTab(currentTab)) lastMainTab = currentTab;
        else if (lastMainTab == TAB_WIFI && !wifiEnabled()) lastMainTab = TAB_SMS;
        else if (lastMainTab == TAB_REGS && !regsEnabled()) lastMainTab = TAB_SMS;
    }

    // ---------------------------------------------------------------- frame (top bar, tab strip, content)

    private void buildFrame() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(14), dp(10), dp(14), dp(8));
        bar.addView(new BoltView(this, true), new LinearLayout.LayoutParams(dp(42), dp(42)));

        TextView title = text("7East controller", 19, TEXT, true);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        tp.setMarginStart(dp(10));
        tp.setMarginEnd(dp(10));
        title.setTextDirection(View.TEXT_DIRECTION_LTR);
        title.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        bar.addView(title, tp);

        statusChip = text("", 12, GREEN, true);
        statusChip.setPadding(dp(10), dp(6), dp(10), dp(6));
        statusChip.setOnClickListener(v -> { if (waiting) showSheet(); });
        bar.addView(statusChip);

        refreshBtn = button("↻", BLUE, Color.WHITE);
        refreshBtn.setTextSize(18);
        refreshBtn.setOnClickListener(v -> refreshAll());
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(dp(44), dp(40));
        rp.setMarginStart(dp(14));
        bar.addView(refreshBtn, rp);

        menuBtn = button("☰", CARD_DARK, TEXT);
        menuBtn.setTextSize(18);
        menuBtn.setOnClickListener(v -> onMenuPressed());
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(dp(44), dp(40));
        mp.setMarginStart(dp(8));
        bar.addView(menuBtn, mp);
        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        tabsRow = new LinearLayout(this);
        tabsRow.setOrientation(LinearLayout.HORIZONTAL);
        tabsRow.setPadding(dp(4), dp(4), dp(4), dp(4));
        tabsRow.setBackground(round(CARD_DARK, 14, BORDER));
        LinearLayout.LayoutParams trp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        trp.setMargins(dp(14), 0, dp(14), dp(6));
        root.addView(tabsRow, trp);

        stateView = text("", 12, MUTED, false);
        stateView.setPadding(dp(16), dp(2), dp(16), dp(8));
        root.addView(stateView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        contentHost = new LinearLayout(this);
        contentHost.setOrientation(LinearLayout.VERTICAL);
        contentHost.setPadding(dp(14), dp(4), dp(14), dp(16));
        scroll.addView(contentHost, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        // Android 15+ draws edge-to-edge: keep the content clear of system bars and the keyboard.
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int l, t, r, b;
            if (Build.VERSION.SDK_INT >= 30) {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                Insets ime = insets.getInsets(WindowInsets.Type.ime());
                l = bars.left; t = bars.top; r = bars.right; b = Math.max(bars.bottom, ime.bottom);
            } else {
                l = insets.getSystemWindowInsetLeft(); t = insets.getSystemWindowInsetTop();
                r = insets.getSystemWindowInsetRight(); b = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(l, t, r, b);
            return insets;
        });
        setContentView(root);
    }

    private void onMenuPressed() {
        if (!isMainTab(currentTab)) {
            currentTab = lastMainTab;
            render(true);
            return;
        }
        PopupMenu menu = new PopupMenu(this, menuBtn);
        if (isAdmin()) menu.getMenu().add(0, PAGE_ADMIN, 0, "🛡  کاربران و مدیران");
        menu.getMenu().add(0, PAGE_SETTINGS, 1, "⚙  تنظیمات");
        menu.getMenu().add(0, PAGE_ABOUT, 2, "ℹ  درباره");
        menu.setOnMenuItemClickListener(item -> {
            currentTab = item.getItemId();
            render(true);
            return true;
        });
        menu.show();
    }

    private void selectTab(int tab) {
        if (currentTab == tab) return;
        currentTab = tab;
        if (tab == TAB_WIFI) checkWifi();
        render(true);
    }

    private void render(boolean force) {
        if (contentHost == null) return;
        normalizeTab();
        updateChrome();
        View focus = getCurrentFocus();
        boolean typing = !force && currentTab == PAGE_SETTINGS && focus instanceof EditText;
        if (!typing) rebuildContent();
    }

    private void updateChrome() {
        statusChip.setText(waiting ? "⏳ در حال اجرا" : "● آماده");
        statusChip.setTextColor(waiting ? AMBER : GREEN);
        statusChip.setBackground(round(waiting ? Color.rgb(68, 48, 22) : Color.rgb(17, 58, 54), 16, waiting ? AMBER : GREEN));
        boolean main = isMainTab(currentTab);
        refreshBtn.setVisibility(main ? View.VISIBLE : View.GONE);
        setEnabledLook(refreshBtn, !waiting);
        menuBtn.setText(main ? "☰" : "✕");
        stateView.setText(stateMessage);

        tabsRow.removeAllViews();
        int count = 1 + (wifiEnabled() ? 1 : 0) + (regsEnabled() ? 1 : 0);
        tabsRow.setVisibility(main && count > 1 ? View.VISIBLE : View.GONE);
        addTabButton(TAB_SMS, "📩 پیامکی");
        if (wifiEnabled()) addTabButton(TAB_WIFI, "📶 وای‌فای");
        if (regsEnabled()) addTabButton(TAB_REGS, "📊 رجیسترها");
    }

    private void addTabButton(final int tab, String label) {
        boolean selected = currentTab == tab;
        Button b = button(label, selected ? BLUE : CARD_DARK, selected ? Color.WHITE : MUTED);
        b.setTextSize(13);
        b.setOnClickListener(v -> selectTab(tab));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(42), 1);
        lp.setMargins(dp(2), 0, dp(2), 0);
        tabsRow.addView(b, lp);
    }

    private void rebuildContent() {
        int keepY = (lastBuiltTab == currentTab) ? scroll.getScrollY() : 0;
        lastBuiltTab = currentTab;
        contentHost.removeAllViews();
        switch (currentTab) {
            case TAB_SMS: renderRelays(false); break;
            case TAB_WIFI: renderRelays(true); break;
            case TAB_REGS: renderRegisters(); break;
            case PAGE_ADMIN: renderAdmin(); break;
            case PAGE_SETTINGS: renderSettings(); break;
            default: renderAbout(); break;
        }
        final int y = keepY;
        scroll.post(() -> scroll.scrollTo(0, y));
    }

    // ---------------------------------------------------------------- relays (SMS tab and Wi-Fi tab)

    private void renderRelays(boolean wifi) {
        int n = activeCoils();
        addSectionTitle(wifi ? "کنترل با وای‌فای" : "کنترل با پیامک", n + " رله");

        if (wifi) renderWifiStatusCard();

        boolean anyToggle = false;
        boolean anyKnown = false;
        for (int i = 0; i < n; i++) {
            if (!relayIsPulse(i)) {
                anyToggle = true;
                if (coilState[i] != -1) anyKnown = true;
            }
        }
        if (anyToggle && !anyKnown) {
            LinearLayout info = card();
            info.addView(text("وضعیت رله‌ها هنوز دریافت نشده است. تا قبل از دریافت وضعیت، لمس دکمهٔ روشن/خاموش فقط وضعیت را می‌گیرد و رله را تغییر نمی‌دهد.", 12, MUTED, false));
            Button b = button("↻ دریافت وضعیت رله‌ها", BLUE, Color.WHITE);
            setEnabledLook(b, !waiting);
            b.setOnClickListener(v -> refreshAll());
            info.addView(b, lp(44, 0, 10, 0, 0));
            contentHost.addView(info, lpMatchWrap(0, 0, 0, 10));
        }

        for (int start = 0; start < n; start += 2) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.TOP);
            row.addView(relayCard(start, wifi), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            row.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
            if (start + 1 < n) row.addView(relayCard(start + 1, wifi), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            else row.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1));
            contentHost.addView(row, lpMatchWrap(0, 0, 0, 8));
        }
        addDetailsReplyCard();
    }

    private void renderWifiStatusCard() {
        LinearLayout c = card();
        String label;
        int color;
        if (wifiChecking || wifiState == 0) { label = "⏳ در حال بررسی اتصال…"; color = AMBER; }
        else if (wifiState == 1) { label = "✓ به کنترلر وصل هستید"; color = GREEN; }
        else { label = "✕ به کنترلر وصل نیستید"; color = RED; }
        c.addView(text(label, 15, color, true));
        if (wifiState == 2 && !wifiChecking) {
            TextView help = text("گوشی را به وای‌فای کنترلر وصل کنید و دوباره بررسی کنید.", 12, MUTED, false);
            help.setPadding(0, dp(4), 0, 0);
            c.addView(help);
        }
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button wifiSettings = button("📶 وای‌فای گوشی", CARD_DARK, TEXT);
        wifiSettings.setOnClickListener(v -> openWifiSettings());
        Button check = button("↻ بررسی اتصال", BLUE, Color.WHITE);
        check.setOnClickListener(v -> checkWifi());
        row.addView(wifiSettings, new LinearLayout.LayoutParams(0, dp(42), 1));
        row.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        row.addView(check, new LinearLayout.LayoutParams(0, dp(42), 1));
        c.addView(row, lpMatchWrap(0, 10, 0, 0));
        contentHost.addView(c, lpMatchWrap(0, 0, 0, 10));
    }

    private void openWifiSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
        } catch (RuntimeException ex) {
            toast("باز کردن تنظیمات وای‌فای ممکن نشد.");
        }
    }

    private void checkWifi() {
        if (wifiChecking) return;
        wifiChecking = true;
        wifiState = 0;
        if (currentTab == TAB_WIFI) render(false);
        WifiApi.ping(getApplicationContext(), wifiIp(), (ok, body, error) -> handler.post(() -> {
            wifiChecking = false;
            wifiState = ok ? 1 : 2;
            if (currentTab == TAB_WIFI) render(false);
        }));
    }

    private View relayCard(final int index, final boolean wifi) {
        LinearLayout c = card();
        final boolean pulseMode = relayIsPulse(index);
        int state = pulseMode ? -1 : coilState[index];
        int stateColor = state == 1 ? GREEN : (state == 0 ? MUTED : AMBER);
        int tileColor = state == 1 ? Color.rgb(17, 58, 54) : (state == 0 ? CARD : (state == 2 ? Color.rgb(68, 48, 22) : CARD_DARK));
        c.setBackground(round(tileColor, 15, state == 1 ? GREEN : (state == 2 ? AMBER : BORDER)));

        LinearLayout nameRow = new LinearLayout(this);
        nameRow.setOrientation(LinearLayout.HORIZONTAL);
        nameRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = text(coilNames[index], 14, TEXT, true);
        name.setMaxLines(2);
        nameRow.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        Button rename = button("✎", CARD_DARK, MUTED);
        rename.setTextSize(12);
        nameRow.addView(rename, new LinearLayout.LayoutParams(dp(36), dp(34)));
        rename.setOnClickListener(v -> editNameDialog(true, index));
        c.addView(nameRow);

        String label;
        if (pulseMode) label = "⚡ لحظه‌ای";
        else label = state == 1 ? "● روشن" : state == 0 ? "○ خاموش" : state == 2 ? "⚡ پالس" : "? نامشخص";
        TextView status = text(label, 13, pulseMode ? MUTED : stateColor, true);
        status.setPadding(0, dp(6), 0, dp(9));
        c.addView(status);

        Button main;
        if (pulseMode) main = button("⚡ فشار بده", AMBER, Color.WHITE);
        else if (state == -1) main = button("↻ رفرش", CARD_DARK, TEXT);
        else if (state == 1) main = button("خاموش کن", RED, Color.WHITE);
        else if (state == 2) main = button("اجرا", AMBER, Color.WHITE);
        else main = button("روشن کن", GREEN, Color.WHITE);
        setEnabledLook(main, !waiting);
        main.setOnClickListener(v -> {
            if (waiting) return;
            if (pulseMode) {
                sendCommand("PULSE " + (index + 1), "PULSE_CMD", index, "لحظه‌ای · " + coilNames[index], wifi);
            } else if (coilState[index] == -1) {
                refreshAll();
            } else {
                sendCommand(String.valueOf(index + 1), "RELAY", index, coilNames[index], wifi);
            }
        });
        c.addView(main, lp(42, 0, 0, 0, 0));
        c.setOnLongClickListener(v -> { editNameDialog(true, index); return true; });
        return c;
    }

    // ---------------------------------------------------------------- registers

    private void renderRegisters() {
        addSectionTitle("رجیسترها", MAX_REGS + " مقدار");
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button refresh = button("↻ دریافت مقادیر", BLUE, Color.WHITE);
        setEnabledLook(refresh, !waiting);
        refresh.setOnClickListener(v -> sendCommand("VARS", "VARS", -1, "دریافت مقدار رجیسترها", false));
        Button all = button("↻ رفرش همه", CARD_DARK, TEXT);
        setEnabledLook(all, !waiting);
        all.setOnClickListener(v -> refreshAll());
        actions.addView(refresh, new LinearLayout.LayoutParams(0, dp(45), 1));
        actions.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        actions.addView(all, new LinearLayout.LayoutParams(0, dp(45), 1));
        contentHost.addView(actions, lpMatchWrap(0, 0, 0, 10));

        for (int start = 0; start < MAX_REGS; start += 2) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.addView(registerCard(start), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            row.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
            if (start + 1 < MAX_REGS) row.addView(registerCard(start + 1), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            else row.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1));
            contentHost.addView(row, lpMatchWrap(0, 0, 0, 8));
        }
        addDetailsReplyCard();
    }

    private View registerCard(final int index) {
        LinearLayout c = card();
        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text(regNames[index], 13, TEXT, true);
        title.setMaxLines(2);
        titleRow.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        Button rename = button("✎", CARD_DARK, MUTED);
        rename.setTextSize(12);
        titleRow.addView(rename, new LinearLayout.LayoutParams(dp(34), dp(32)));
        rename.setOnClickListener(v -> editNameDialog(false, index));
        c.addView(titleRow, lpMatchWrap(0, 0, 0, 6));
        TextView val = text(regKnown[index] ? String.valueOf(regValue[index]) : "—", 21, regKnown[index] ? BLUE : AMBER, true);
        val.setPadding(0, dp(2), 0, dp(8));
        c.addView(val);
        Button edit = button("✎ تغییر مقدار", PURPLE, Color.WHITE);
        setEnabledLook(edit, !waiting);
        edit.setOnClickListener(v -> editRegisterValue(index));
        c.addView(edit, lp(42, 0, 0, 0, 0));
        return c;
    }

    // ---------------------------------------------------------------- admin page (users / admins only)

    private void renderAdmin() {
        addSectionTitle("کاربران و مدیران", "فقط مدیر");
        LinearLayout caution = card();
        caution.addView(text("شمارهٔ موبایل فرد را وارد کنید تا به کنترلر اضافه یا از آن حذف شود. این کار فقط وقتی انجام می‌شود که شمارهٔ همین گوشی در کنترلر «مدیر» باشد.", 13, MUTED, false));
        contentHost.addView(caution, lpMatchWrap(0, 0, 0, 10));

        addAdminButton("➕  افزودن کاربر", "ADUS", "افزودن کاربر", GREEN);
        addAdminButton("➖  حذف کاربر", "DELUS", "حذف کاربر", RED);
        addAdminButton("➕  افزودن مدیر", "ADAD", "افزودن مدیر", GREEN);
        addAdminButton("➖  حذف مدیر", "DELAD", "حذف مدیر", RED);
        addDetailsReplyCard();
    }

    private void addAdminButton(String label, final String command, final String title, int color) {
        Button b = button(label, color, Color.WHITE);
        b.setTextSize(14);
        setEnabledLook(b, !waiting);
        b.setOnClickListener(v -> showAdminDialog(command, title));
        contentHost.addView(b, lp(50, 0, 0, 0, 9));
    }

    private void showAdminDialog(final String command, final String title) {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_PHONE);
        input.setHint("مثلاً 0912xxxxxxx");
        input.setTextColor(TEXT);
        input.setHintTextColor(MUTED);
        input.setBackground(round(CARD_DARK, 10, BORDER));
        input.setPadding(dp(12), dp(6), dp(12), dp(6));
        LinearLayout wrap = new LinearLayout(this);
        wrap.setPadding(dp(20), dp(4), dp(20), dp(4));
        wrap.addView(input, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)));
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage("شمارهٔ موبایل را وارد کنید.")
                .setView(wrap)
                .setNegativeButton("انصراف", null)
                .setPositiveButton("ارسال", (dialog, which) -> {
                    String phone = normalizePhone(input.getText().toString());
                    if (phone.length() < 10 || phone.length() > 15) {
                        toast("شماره را کامل و صحیح وارد کنید.");
                        return;
                    }
                    pendingAdminPhone = phone;
                    sendCommand(command, "ADMIN", -1, title, false);
                }).show();
    }

    // ---------------------------------------------------------------- settings page

    private void renderSettings() {
        addSectionTitle("تنظیمات", "فقط روی همین گوشی ذخیره می‌شود");
        settingsRoleCard();
        settingsControllerNumberCard();
        settingsSimCard();
        settingsWifiCard();
        settingsRelayCountCard();
        settingsRelayModeCard();
        settingsSectionsCard();
        settingsPermissionCard();
    }

    private LinearLayout settingsCard(String title, String detail) {
        LinearLayout c = card();
        c.addView(text(title, 15, TEXT, true));
        if (detail != null) {
            TextView d = text(detail, 12, MUTED, false);
            d.setPadding(0, dp(3), 0, 0);
            c.addView(d);
        }
        contentHost.addView(c, lpMatchWrap(0, 0, 0, 10));
        return c;
    }

    private void settingsRoleCard() {
        LinearLayout c = settingsCard("نوع کاربر", "«کاربر ساده» بخش کاربران و مدیران را نمی‌بیند.");
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        boolean admin = isAdmin();
        Button user = button("👤 کاربر ساده", admin ? CARD_DARK : BLUE, admin ? MUTED : Color.WHITE);
        user.setOnClickListener(v -> { prefs.edit().putBoolean("is_admin", false).apply(); render(true); });
        Button adm = button("🛡 مدیر", admin ? BLUE : CARD_DARK, admin ? Color.WHITE : MUTED);
        adm.setOnClickListener(v -> { prefs.edit().putBoolean("is_admin", true).apply(); render(true); });
        row.addView(user, new LinearLayout.LayoutParams(0, dp(44), 1));
        row.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        row.addView(adm, new LinearLayout.LayoutParams(0, dp(44), 1));
        c.addView(row, lpMatchWrap(0, 10, 0, 0));
    }

    private void settingsControllerNumberCard() {
        LinearLayout c = settingsCard("شمارهٔ سیم‌کارت کنترلر",
                "فرمان‌های پیامکی به این شماره فرستاده می‌شود. شمارهٔ سیم‌کارتی را بنویسید که داخل کنترلر است، نه شمارهٔ این گوشی.");
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        deviceNumberInput = makeInput("مثلاً 0912xxxxxxx", InputType.TYPE_CLASS_PHONE, deviceNumber());
        row.addView(deviceNumberInput, new LinearLayout.LayoutParams(0, dp(48), 1));
        Button save = button("ذخیره", GREEN, Color.WHITE);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(dp(80), dp(48));
        sp.setMarginStart(dp(7));
        row.addView(save, sp);
        save.setOnClickListener(v -> {
            String raw = deviceNumberInput.getText().toString().trim();
            if (normalizePhone(raw).length() < 10) {
                toast("شمارهٔ سیم‌کارت کنترلر را کامل وارد کنید.");
                return;
            }
            prefs.edit().putString("device_number", raw).apply();
            hideKeyboard();
            stateMessage = "شمارهٔ کنترلر ذخیره شد.";
            toast("شماره ذخیره شد.");
            render(true);
        });
        c.addView(row, lpMatchWrap(0, 8, 0, 0));
    }

    private void settingsSimCard() {
        LinearLayout c = settingsCard("سیم‌کارت ارسال پیامک",
                "اگر گوشی شما دو سیم‌کارت دارد، انتخاب کنید پیامک‌ها با کدام سیم‌کارت فرستاده شود.");
        if (!hasPhoneStatePermission()) {
            Button detect = button("🔍 تشخیص سیم‌کارت‌های گوشی", BLUE, Color.WHITE);
            detect.setOnClickListener(v -> {
                if (Build.VERSION.SDK_INT >= 23) requestPermissions(new String[]{Manifest.permission.READ_PHONE_STATE}, REQUEST_PHONE_STATE);
            });
            c.addView(detect, lp(44, 0, 10, 0, 0));
            return;
        }
        List<SubscriptionInfo> sims = null;
        try {
            SubscriptionManager sm = (SubscriptionManager) getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
            if (sm != null) sims = sm.getActiveSubscriptionInfoList();
        } catch (SecurityException ignored) { }
        if (sims == null || sims.size() < 2) {
            TextView t = text("✓ گوشی شما یک سیم‌کارت فعال دارد؛ همان استفاده می‌شود.", 12, GREEN, true);
            t.setPadding(0, dp(8), 0, 0);
            c.addView(t);
            return;
        }
        int selected = simSubId();
        c.addView(simOption("پیش‌فرض گوشی", -1, selected == -1), lp(44, 0, 10, 0, 0));
        for (SubscriptionInfo info : sims) {
            CharSequence carrier = info.getDisplayName();
            String label = "سیم‌کارت " + (info.getSimSlotIndex() + 1) + (carrier != null && carrier.length() > 0 ? "  ·  " + carrier : "");
            c.addView(simOption(label, info.getSubscriptionId(), selected == info.getSubscriptionId()), lp(44, 0, 8, 0, 0));
        }
    }

    private Button simOption(String label, final int subId, boolean selected) {
        Button b = button((selected ? "●  " : "○  ") + label, selected ? BLUE : CARD_DARK, selected ? Color.WHITE : TEXT);
        b.setOnClickListener(v -> {
            prefs.edit().putInt("sim_sub_id", subId).apply();
            render(true);
        });
        return b;
    }

    private void settingsWifiCard() {
        LinearLayout c = settingsCard("وای‌فای", "با وای‌فای می‌توانید وقتی کنار کنترلر هستید، سریع و بدون هزینهٔ پیامک فرمان بدهید.");
        c.addView(makeSwitch("نمایش تب وای‌فای", null, wifiEnabled(), on -> {
            prefs.edit().putBoolean("wifi_enabled", on).apply();
            handler.post(() -> render(true));
        }), lpMatchWrap(0, 8, 0, 0));

        TextView ipLabel = text("آدرس (IP) کنترلر", 13, TEXT, true);
        ipLabel.setPadding(0, dp(10), 0, dp(4));
        c.addView(ipLabel);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        wifiIpInput = makeInput(WifiApi.DEFAULT_IP, InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI, wifiIp());
        wifiIpInput.setTextDirection(View.TEXT_DIRECTION_LTR);
        wifiIpInput.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        row.addView(wifiIpInput, new LinearLayout.LayoutParams(0, dp(48), 1));
        Button save = button("ذخیره", GREEN, Color.WHITE);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(dp(80), dp(48));
        sp.setMarginStart(dp(7));
        row.addView(save, sp);
        save.setOnClickListener(v -> {
            String ip = wifiIpInput.getText().toString().trim();
            if (!ip.matches("[A-Za-z0-9.\\-]+(:\\d{1,5})?")) {
                toast("آدرس معتبر نیست. مثال: 192.168.4.1");
                return;
            }
            prefs.edit().putString("wifi_ip", ip).apply();
            hideKeyboard();
            wifiState = 0;
            stateMessage = "آدرس کنترلر ذخیره شد.";
            toast("آدرس ذخیره شد.");
            render(true);
        });
        c.addView(row);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        Button reset = button("↺ آدرس پیش‌فرض", CARD_DARK, TEXT);
        reset.setOnClickListener(v -> {
            prefs.edit().putString("wifi_ip", WifiApi.DEFAULT_IP).apply();
            hideKeyboard();
            wifiState = 0;
            render(true);
        });
        Button test = button("آزمایش اتصال", BLUE, Color.WHITE);
        test.setOnClickListener(v -> {
            toast("در حال آزمایش اتصال…");
            WifiApi.ping(getApplicationContext(), wifiIp(), (ok, body, error) -> handler.post(() -> {
                wifiState = ok ? 1 : 2;
                toast(ok ? "به کنترلر وصل شد ✓" : "به کنترلر وصل نشد. گوشی را به وای‌فای کنترلر وصل کنید.");
                render(false);
            }));
        });
        row2.addView(reset, new LinearLayout.LayoutParams(0, dp(42), 1));
        row2.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        row2.addView(test, new LinearLayout.LayoutParams(0, dp(42), 1));
        c.addView(row2, lpMatchWrap(0, 8, 0, 0));

        Button phoneWifi = button("📶 باز کردن وای‌فای گوشی", CARD_DARK, TEXT);
        phoneWifi.setOnClickListener(v -> openWifiSettings());
        c.addView(phoneWifi, lp(42, 0, 8, 0, 0));

        if (techDetails()) {
            TextView tplLabel = text("قالب آدرس فرمان (پیشرفته)", 13, TEXT, true);
            tplLabel.setPadding(0, dp(12), 0, dp(4));
            c.addView(tplLabel);
            c.addView(text("هر جا {cmd} باشد با متن فرمان جایگزین می‌شود.", 11, MUTED, false));
            LinearLayout row3 = new LinearLayout(this);
            row3.setOrientation(LinearLayout.HORIZONTAL);
            row3.setGravity(Gravity.CENTER_VERTICAL);
            wifiTplInput = makeInput(WifiApi.DEFAULT_TEMPLATE, InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI, wifiTemplate());
            wifiTplInput.setTextDirection(View.TEXT_DIRECTION_LTR);
            wifiTplInput.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
            row3.addView(wifiTplInput, new LinearLayout.LayoutParams(0, dp(48), 1));
            Button saveTpl = button("ذخیره", GREEN, Color.WHITE);
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(dp(80), dp(48));
            tp.setMarginStart(dp(7));
            row3.addView(saveTpl, tp);
            saveTpl.setOnClickListener(v -> {
                String tpl = wifiTplInput.getText().toString().trim();
                if (tpl.isEmpty()) tpl = WifiApi.DEFAULT_TEMPLATE;
                prefs.edit().putString("wifi_template", tpl).apply();
                hideKeyboard();
                toast("ذخیره شد.");
                render(true);
            });
            c.addView(row3, lpMatchWrap(0, 4, 0, 0));
        }
    }

    private void settingsRelayCountCard() {
        int n = activeCoils();
        LinearLayout c = settingsCard("تعداد رله‌های فعال", "فقط همین تعداد رله نشان داده می‌شود (۱ تا ۴۰).");
        LinearLayout stepper = new LinearLayout(this);
        stepper.setOrientation(LinearLayout.HORIZONTAL);
        stepper.setGravity(Gravity.CENTER_VERTICAL);
        Button minus = button("−", CARD_DARK, TEXT);
        minus.setTextSize(20);
        minus.setOnClickListener(v -> setActiveCoils(activeCoils() - 1));
        TextView value = text(n + " از " + MAX_COILS, 17, BLUE, true);
        value.setGravity(Gravity.CENTER);
        Button plus = button("+", CARD_DARK, TEXT);
        plus.setTextSize(20);
        plus.setOnClickListener(v -> setActiveCoils(activeCoils() + 1));
        stepper.addView(minus, new LinearLayout.LayoutParams(dp(52), dp(46)));
        stepper.addView(value, new LinearLayout.LayoutParams(0, dp(46), 1));
        stepper.addView(plus, new LinearLayout.LayoutParams(dp(52), dp(46)));
        c.addView(stepper, lpMatchWrap(0, 8, 0, 6));
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        int[] presets = {4, 8, 10, 16, 24, 40};
        for (final int p : presets) {
            Button chip = button(String.valueOf(p), p == n ? BLUE : CARD_DARK, p == n ? Color.WHITE : MUTED);
            chip.setTextSize(12);
            chip.setOnClickListener(v -> setActiveCoils(p));
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, dp(38), 1);
            cp.setMargins(dp(2), 0, dp(2), 0);
            chips.addView(chip, cp);
        }
        c.addView(chips);
    }

    private void settingsRelayModeCard() {
        int n = activeCoils();
        LinearLayout c = settingsCard("نوع هر رله",
                "«ثابت» یعنی روشن می‌ماند تا خاموشش کنید. «لحظه‌ای» یعنی فقط یک لحظه فعال می‌شود (مثل زنگ یا درب‌بازکن). هر رله فقط یک دکمه نشان می‌دهد.");
        LinearLayout bulk = new LinearLayout(this);
        bulk.setOrientation(LinearLayout.HORIZONTAL);
        Button allToggle = button("همه ثابت", CARD_DARK, TEXT);
        allToggle.setOnClickListener(v -> setAllRelayModes(false));
        Button allPulse = button("همه لحظه‌ای", CARD_DARK, AMBER);
        allPulse.setOnClickListener(v -> setAllRelayModes(true));
        bulk.addView(allToggle, new LinearLayout.LayoutParams(0, dp(40), 1));
        bulk.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        bulk.addView(allPulse, new LinearLayout.LayoutParams(0, dp(40), 1));
        c.addView(bulk, lpMatchWrap(0, 10, 0, 6));

        for (int i = 0; i < n; i++) {
            final int index = i;
            boolean pulse = relayIsPulse(i);
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            TextView name = text(coilNames[i], 13, TEXT, false);
            name.setMaxLines(1);
            row.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            Button t = button("ثابت", pulse ? CARD_DARK : BLUE, pulse ? MUTED : Color.WHITE);
            t.setTextSize(12);
            t.setOnClickListener(v -> { prefs.edit().putBoolean("relay_pulse_" + index, false).apply(); render(true); });
            Button p = button("⚡ لحظه‌ای", pulse ? AMBER : CARD_DARK, pulse ? Color.WHITE : MUTED);
            p.setTextSize(12);
            p.setOnClickListener(v -> { prefs.edit().putBoolean("relay_pulse_" + index, true).apply(); render(true); });
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(dp(64), dp(36));
            LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(86), dp(36));
            pp.setMarginStart(dp(6));
            row.addView(t, tp);
            row.addView(p, pp);
            c.addView(row, lpMatchWrap(0, 4, 0, 0));
        }
    }

    private void setAllRelayModes(boolean pulse) {
        SharedPreferences.Editor e = prefs.edit();
        for (int i = 0; i < MAX_COILS; i++) e.putBoolean("relay_pulse_" + i, pulse);
        e.apply();
        render(true);
    }

    private void settingsSectionsCard() {
        LinearLayout c = settingsCard("بخش‌های برنامه", null);
        c.addView(makeSwitch("تب رجیسترها", "اگر از رجیستر استفاده نمی‌کنید خاموشش کنید.", regsEnabled(), on -> {
            prefs.edit().putBoolean("regs_enabled", on).apply();
            handler.post(() -> render(true));
        }), lpMatchWrap(0, 8, 0, 0));
        c.addView(makeSwitch("نمایش جزئیات فنی", "برای تکنسین: متن خام پاسخ کنترلر و تنظیمات پیشرفته را نشان می‌دهد.", techDetails(), on -> {
            prefs.edit().putBoolean("tech_details", on).apply();
            handler.post(() -> render(true));
        }), lpMatchWrap(0, 10, 0, 0));
    }

    private void settingsPermissionCard() {
        LinearLayout c = settingsCard("مجوز پیامک", null);
        boolean ok = hasSmsPermissions();
        TextView permState = text(ok ? "✓ مجوز ارسال و دریافت پیامک فعال است." : "✕ مجوز پیامک فعال نیست؛ برنامه نمی‌تواند پیامک بفرستد.", 12, ok ? GREEN : RED, true);
        permState.setPadding(0, dp(6), 0, dp(4));
        c.addView(permState);
        if (!ok) {
            c.addView(text("اگر اندروید اجازه نمی‌دهد: «اطلاعات برنامه» را باز کنید، از منوی ⋮ بالا گزینهٔ «Allow restricted settings» را بزنید و بعد مجوز پیامک (SMS) را بدهید.", 11, MUTED, false));
            Button ask = button("درخواست مجوز", BLUE, Color.WHITE);
            ask.setOnClickListener(v -> ensureSmsPermissions());
            c.addView(ask, lp(42, 0, 8, 0, 0));
        }
        Button openSettings = button("باز کردن اطلاعات برنامه", CARD_DARK, TEXT);
        openSettings.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", getPackageName(), null)));
            } catch (RuntimeException ex) {
                toast("باز کردن تنظیمات ممکن نشد.");
            }
        });
        c.addView(openSettings, lp(42, 0, 8, 0, 0));
    }

    private EditText makeInput(String hint, int inputType, String value) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setTextSize(15);
        e.setTextColor(TEXT);
        e.setHintTextColor(MUTED);
        e.setHint(hint);
        e.setInputType(inputType);
        e.setText(value);
        e.setPadding(dp(10), dp(6), dp(10), dp(6));
        e.setBackground(round(CARD_DARK, 10, BORDER));
        return e;
    }

    private interface OnToggle { void changed(boolean on); }

    private View makeSwitch(String title, String detail, boolean checked, final OnToggle listener) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        Switch sw = new Switch(this);
        sw.setText(title);
        sw.setTextColor(TEXT);
        sw.setTextSize(14);
        sw.setChecked(checked);
        int[][] states = {{android.R.attr.state_checked}, {}};
        sw.setThumbTintList(new ColorStateList(states, new int[]{BLUE, MUTED}));
        sw.setTrackTintList(new ColorStateList(states, new int[]{Color.argb(120, 14, 165, 233), Color.argb(90, 157, 174, 197)}));
        sw.setOnCheckedChangeListener((b, on) -> listener.changed(on));
        box.addView(sw, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)));
        if (detail != null) box.addView(text(detail, 11, MUTED, false));
        return box;
    }

    private void hideKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null && root != null) imm.hideSoftInputFromWindow(root.getWindowToken(), 0);
            View f = getCurrentFocus();
            if (f != null) f.clearFocus();
        } catch (RuntimeException ignored) { }
    }

    // ---------------------------------------------------------------- about page

    private void renderAbout() {
        LinearLayout head = card();
        head.setGravity(Gravity.CENTER_HORIZONTAL);
        head.addView(new BoltView(this, true), new LinearLayout.LayoutParams(dp(84), dp(84)));
        TextView name = text("7East controller", 21, TEXT, true);
        name.setGravity(Gravity.CENTER);
        name.setPadding(0, dp(10), 0, 0);
        name.setTextDirection(View.TEXT_DIRECTION_LTR);
        head.addView(name);
        TextView ver = text("نسخهٔ " + versionName(), 12, MUTED, false);
        ver.setGravity(Gravity.CENTER);
        head.addView(ver);
        contentHost.addView(head, lpMatchWrap(0, 4, 0, 10));

        addAbout("این برنامه چه کار می‌کند؟",
                "با این برنامه، رله‌های کنترلر را از روی گوشی روشن و خاموش می‌کنید؛ از نزدیک با وای‌فای و از راه دور با پیامک.");

        addAbout("سه قدم ساده",
                "۱) از منوی ☰ بالا، «تنظیمات» را باز کنید و شمارهٔ سیم‌کارتِ کنترلر را بنویسید.\n\n"
              + "۲) دکمهٔ ↻ بالای صفحه را بزنید تا وضعیت رله‌ها بیاید.\n\n"
              + "۳) روی دکمهٔ هر رله بزنید. پنجرهٔ پایین صفحه به شما می‌گوید فرمان انجام شد یا نه.");

        addAbout("پیامکی یا وای‌فای؟",
                "📩 پیامکی: از هر جا که آنتن دارید کار می‌کند. جواب کمی دیرتر می‌رسد و هزینهٔ پیامک دارد.\n\n"
              + "📶 وای‌فای: وقتی کنار کنترلر هستید. اول گوشی را به وای‌فای کنترلر وصل کنید. سریع است و هزینه ندارد.");

        addAbout("رنگ‌ها یعنی چه؟",
                "🟢 سبز: روشن\n⚪ خاکستری: خاموش\n🟠 نارنجی: هنوز نمی‌دانیم؛ دکمهٔ رفرش را بزنید.\n\n"
              + "رلهٔ «لحظه‌ای» فقط یک لحظه فعال می‌شود و خودش برمی‌گردد؛ مثل زنگ یا درب‌بازکن.");

        addAbout("اگر جواب نیامد",
                "نگران نباشید. برنامه خودش فرمان را دوباره نمی‌فرستد تا اشتباهی رله برعکس نشود. دکمهٔ ↻ را بزنید، وضعیت را ببینید و اگر لازم بود دوباره امتحان کنید.");
    }

    private void addAbout(String title, String body) {
        LinearLayout c = card();
        c.addView(text(title, 16, BLUE, true));
        TextView t = text(body, 15, TEXT, false);
        t.setLineSpacing(dp(4), 1.0f);
        t.setPadding(0, dp(8), 0, 0);
        c.addView(t);
        contentHost.addView(c, lpMatchWrap(0, 0, 0, 10));
    }

    private String versionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception ex) {
            return "1.2";
        }
    }

    /** Raw controller reply: only for technicians (settings → technical details). */
    private void addDetailsReplyCard() {
        if (!techDetails() || lastReply.isEmpty()) return;
        LinearLayout c = card();
        c.addView(text("آخرین پاسخ خام کنترلر", 13, TEXT, true));
        TextView response = text(lastReply, 12, TEXT, false);
        response.setTypeface(Typeface.MONOSPACE);
        response.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG_LTR);
        response.setGravity(Gravity.START);
        response.setPadding(0, dp(8), 0, 0);
        c.addView(response);
        contentHost.addView(c, lpMatchWrap(0, 4, 0, 8));
    }

    // ---------------------------------------------------------------- dialogs

    private void refreshAll() {
        if (waiting) return;
        boolean wifi = currentTab == TAB_WIFI;
        Arrays.fill(coilState, -1);
        for (int i = 0; i < MAX_REGS; i++) regKnown[i] = false;
        sendCommand("STATUS", "STATUS", -1, regsEnabled() ? "دریافت وضعیت رله‌ها و رجیسترها" : "دریافت وضعیت رله‌ها", wifi);
    }

    private void editNameDialog(boolean coil, int index) {
        EditText input = new EditText(this);
        input.setText(coil ? coilNames[index] : regNames[index]);
        input.setSingleLine(true);
        input.setTextColor(TEXT);
        input.setHintTextColor(MUTED);
        input.setPadding(dp(12), dp(7), dp(12), dp(7));
        input.setBackground(round(CARD_DARK, 10, BORDER));
        LinearLayout wrap = new LinearLayout(this);
        wrap.setPadding(dp(20), dp(4), dp(20), dp(4));
        wrap.addView(input, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)));
        new AlertDialog.Builder(this)
                .setTitle(coil ? "نام رلهٔ " + (index + 1) : "نام رجیستر " + (index + 1))
                .setView(wrap)
                .setNegativeButton("انصراف", null)
                .setPositiveButton("ذخیره", (dialog, which) -> {
                    String value = input.getText().toString().trim();
                    if (value.isEmpty()) value = coil ? "رله " + (index + 1) : "رجیستر " + (index + 1);
                    if (coil) {
                        coilNames[index] = value;
                        prefs.edit().putString("coil_name_" + index, value).apply();
                    } else {
                        regNames[index] = value;
                        prefs.edit().putString("reg_name_" + index, value).apply();
                    }
                    render(true);
                }).show();
    }

    private void editRegisterValue(int index) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
        input.setText(regKnown[index] ? String.valueOf(regValue[index]) : "0");
        input.setTextColor(TEXT);
        input.setPadding(dp(12), dp(6), dp(12), dp(6));
        input.setBackground(round(CARD_DARK, 10, BORDER));
        LinearLayout wrap = new LinearLayout(this);
        wrap.setPadding(dp(20), dp(4), dp(20), dp(4));
        wrap.addView(input, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)));
        new AlertDialog.Builder(this)
                .setTitle("مقدار جدید برای " + regNames[index])
                .setMessage("یک عدد بین 0 و 65535 بنویسید.")
                .setView(wrap)
                .setNegativeButton("انصراف", null)
                .setPositiveButton("ثبت", (dialog, which) -> {
                    String raw = input.getText().toString().trim();
                    int value;
                    try { value = Integer.parseInt(raw); } catch (NumberFormatException ex) { value = -1; }
                    if (value < 0 || value > 65535) {
                        toast("مقدار باید بین 0 و 65535 باشد.");
                        return;
                    }
                    sendCommand("SET " + (index + 1) + " " + value, "REGWRITE", index,
                            "ثبت «" + regNames[index] + "» = " + value, false);
                }).show();
    }

    // ---------------------------------------------------------------- command tracker (status sheet)

    private void showSheet() {
        if (sheet != null && sheet.isShowing()) { updateSheet(); return; }
        sheet = new Dialog(this);
        sheet.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        box.setPadding(dp(20), dp(10), dp(20), dp(22));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(CARD);
        float r = dp(24);
        bg.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        bg.setStroke(dp(1), BORDER);
        box.setBackground(bg);

        View handle = new View(this);
        handle.setBackground(round(BORDER, 3, BORDER));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(dp(44), dp(5));
        hp.gravity = Gravity.CENTER_HORIZONTAL;
        hp.setMargins(0, 0, 0, dp(14));
        box.addView(handle, hp);

        shTitle = text("", 19, AMBER, true);
        box.addView(shTitle);
        shCode = text("", 13, MUTED, false);
        shCode.setPadding(0, dp(3), 0, dp(10));
        box.addView(shCode);

        shBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        shBar.setIndeterminate(true);
        shBar.setIndeterminateTintList(ColorStateList.valueOf(BLUE));
        box.addView(shBar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(6)));

        for (int i = 0; i < 3; i++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            shIcon[i] = text("○", 18, MUTED, true);
            shIcon[i].setGravity(Gravity.CENTER);
            row.addView(shIcon[i], new LinearLayout.LayoutParams(dp(34), dp(34)));
            shLabel[i] = text("", 15, MUTED, false);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
            lp.setMarginStart(dp(8));
            row.addView(shLabel[i], lp);
            box.addView(row, i == 0 ? lp(40, 0, 12, 0, 0) : lp(40, 0, 0, 0, 0));
        }

        shDetail = text("", 14, TEXT, false);
        shDetail.setPadding(0, dp(10), 0, 0);
        box.addView(shDetail);

        shReply = text("", 12, TEXT, false);
        shReply.setTypeface(Typeface.MONOSPACE);
        shReply.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG_LTR);
        shReply.setGravity(Gravity.START);
        shReply.setPadding(dp(10), dp(8), dp(10), dp(8));
        shReply.setBackground(round(CARD_DARK, 10, BORDER));
        box.addView(shReply, lpMatchWrap(0, 10, 0, 0));

        shTimer = text("", 12, MUTED, false);
        shTimer.setPadding(0, dp(8), 0, 0);
        box.addView(shTimer);

        shAction = button("↻ رفرش وضعیت", BLUE, Color.WHITE);
        shAction.setOnClickListener(v -> {
            sheet.dismiss();
            refreshAll();
        });
        box.addView(shAction, lp(44, 0, 12, 0, 0));

        shClose = button("بستن", CARD_DARK, TEXT);
        shClose.setOnClickListener(v -> sheet.dismiss());
        box.addView(shClose, lp(44, 0, 8, 0, 0));

        sheet.setContentView(box);
        Window w = sheet.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            w.setGravity(Gravity.BOTTOM);
            w.setWindowAnimations(android.R.style.Animation_InputMethod);
        }
        updateSheet();
        sheet.show();
        handler.removeCallbacks(ticker);
        if (waiting) handler.postDelayed(ticker, 1000L);
    }

    private long timeoutMs() { return txWifi ? WIFI_TIMEOUT_MS : SMS_TIMEOUT_MS; }

    private void updateSheet() {
        if (sheet == null || !sheet.isShowing() || shTitle == null) return;
        boolean running = cmdPhase == PH_SENDING || cmdPhase == PH_WAITING;
        String head;
        int color;
        switch (cmdPhase) {
            case PH_SENDING: head = "در حال ارسال فرمان…"; color = AMBER; break;
            case PH_WAITING: head = "منتظر پاسخ کنترلر…"; color = AMBER; break;
            case PH_OK: head = "فرمان تأیید شد ✓"; color = GREEN; break;
            case PH_ERR: head = "فرمان انجام نشد ✕"; color = RED; break;
            default: head = "پاسخی دریافت نشد"; color = AMBER; break;
        }
        shTitle.setText(head);
        shTitle.setTextColor(color);
        shCode.setText(cmdTitle + (techDetails() && !cmdCode.isEmpty() ? "   ·   " + cmdCode : ""));
        shBar.setVisibility(running ? View.VISIBLE : View.INVISIBLE);

        shLabel[0].setText(txWifi ? "ارسال فرمان به کنترلر (وای‌فای)" : "ارسال پیامک به کنترلر");
        shLabel[1].setText("پاسخ کنترلر");
        shLabel[2].setText("نتیجه");

        // 0 = pending, 1 = active, 2 = done, 3 = error
        int s1, s2, s3;
        switch (cmdPhase) {
            case PH_SENDING: s1 = 1; s2 = 0; s3 = 0; break;
            case PH_WAITING: s1 = 2; s2 = 1; s3 = 0; break;
            case PH_OK: s1 = 2; s2 = 2; s3 = 2; break;
            case PH_ERR:
                s1 = cmdSmsSent ? 2 : 3;
                s2 = cmdGotReply ? 2 : 0;
                s3 = 3;
                break;
            default: s1 = cmdSmsSent ? 2 : 3; s2 = 3; s3 = 0; break;
        }
        applyStep(0, s1);
        applyStep(1, s2);
        applyStep(2, s3);

        String detail;
        if (cmdPhase == PH_SENDING) detail = txWifi ? "فرمان در حال ارسال به کنترلر است." : "پیامک در حال ارسال به کنترلر است.";
        else if (cmdPhase == PH_WAITING) detail = txWifi ? "فرمان رسید؛ منتظر پاسخ کنترلر هستیم." : "پیامک ارسال شد. پاسخ کنترلر معمولاً چند ثانیه تا یک دقیقه طول می‌کشد.";
        else detail = cmdResult;
        if (running && !cmdNote.isEmpty()) detail = cmdNote + "\n" + detail;
        shDetail.setText(detail);
        shDetail.setTextColor(cmdPhase == PH_ERR ? RED : TEXT);

        if (!techDetails() || cmdReply.isEmpty()) {
            shReply.setVisibility(View.GONE);
        } else {
            shReply.setVisibility(View.VISIBLE);
            shReply.setText(cmdReply);
        }
        if (running) {
            long sec = Math.max(0L, (System.currentTimeMillis() - cmdPhaseStart) / 1000L);
            shTimer.setText("⏱ " + sec + " ثانیه از " + (timeoutMs() / 1000L));
            shTimer.setVisibility(View.VISIBLE);
        } else {
            shTimer.setVisibility(View.GONE);
        }
        shAction.setVisibility(cmdPhase == PH_TIMEOUT ? View.VISIBLE : View.GONE);
        shClose.setText(running ? "بستن (فرمان ادامه دارد)" : "تأیید");
    }

    private void applyStep(int i, int state) {
        String icon;
        int color;
        switch (state) {
            case 1: icon = "◌"; color = AMBER; break;
            case 2: icon = "✓"; color = GREEN; break;
            case 3: icon = "✕"; color = RED; break;
            default: icon = "○"; color = MUTED; break;
        }
        shIcon[i].setText(icon);
        shIcon[i].setTextColor(color);
        shLabel[i].setTextColor(state == 0 ? MUTED : TEXT);
        shLabel[i].setTypeface(Typeface.DEFAULT, state == 1 ? Typeface.BOLD : Typeface.NORMAL);
    }

    // ---------------------------------------------------------------- sending and transactions

    private void sendCommand(String command, String expected, int index, String title, boolean wifi) {
        if (waiting) return;
        if (!"ADMIN".equals(expected)) pendingAdminPhone = "";
        if (wifi) {
            if (wifiIp().isEmpty()) {
                stateMessage = "آدرس کنترلر در تنظیمات وارد نشده است.";
                currentTab = PAGE_SETTINGS;
                render(true);
                return;
            }
        } else {
            if (!hasSmsPermissions()) {
                pendingAdminPhone = "";
                ensureSmsPermissions();
                stateMessage = "ابتدا اجازهٔ ارسال و دریافت پیامک را فعال کنید.";
                render(true);
                return;
            }
            if (normalizePhone(deviceNumber()).length() < 10) {
                pendingAdminPhone = "";
                stateMessage = "شمارهٔ سیم‌کارت کنترلر وارد نشده است.";
                toast("ابتدا در تنظیمات شمارهٔ سیم‌کارت کنترلر را وارد و ذخیره کنید.");
                currentTab = PAGE_SETTINGS;
                render(true);
                return;
            }
        }
        waiting = true;
        txWifi = wifi;
        expectedType = expected;
        expectedIndex = index;
        pendingCommand = command;
        activeToken = nextToken();
        final long token = activeToken;

        cmdTitle = title;
        cmdCode = command;
        cmdNote = "";
        cmdResult = "";
        cmdReply = "";
        cmdSmsSent = false;
        cmdGotReply = false;
        cmdPhase = PH_SENDING;
        cmdPhaseStart = System.currentTimeMillis();
        stateMessage = "فرمان ارسال شد؛ منتظر پاسخ کنترلر هستیم.";
        armTimeout(token);
        render(true);
        showSheet();
        transmit(command, token);
    }

    private void transmit(String command, long token) {
        if (txWifi) transmitWifi(command, token);
        else transmitSms(normalizePhone(deviceNumber()), command, token);
    }

    private SmsManager smsManager() {
        int sub = simSubId();
        if (sub >= 0 && Build.VERSION.SDK_INT >= 22) {
            try {
                SmsManager m = Build.VERSION.SDK_INT >= 31
                        ? getSystemService(SmsManager.class).createForSubscriptionId(sub)
                        : SmsManager.getSmsManagerForSubscriptionId(sub);
                if (m != null) return m;
            } catch (RuntimeException ignored) {
                // The chosen SIM is gone: fall back to the phone's default SIM below.
            }
        }
        return Build.VERSION.SDK_INT >= 31 ? getSystemService(SmsManager.class) : SmsManager.getDefault();
    }

    private void transmitSms(String dest, String command, long token) {
        try {
            SmsManager manager = smsManager();
            Intent sent = new Intent(this, SmsSentReceiver.class);
            sent.setAction(SmsSentReceiver.ACTION_SENT);
            sent.putExtra("token", token);
            int req = (int) (token & 0x7fffffff);
            PendingIntent sentPI = PendingIntent.getBroadcast(this, req, sent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            manager.sendTextMessage(dest, null, command, sentPI, null);
        } catch (Exception ex) {
            endTransaction(PH_ERR, "ارسال پیامک شروع نشد: " + safeMessage(ex));
        }
    }

    private void transmitWifi(String command, final long token) {
        WifiApi.request(getApplicationContext(), wifiIp(), wifiTemplate(), command,
                (ok, body, error) -> handler.post(() -> onWifiResult(token, ok, body, error)));
    }

    private void onWifiResult(long token, boolean ok, String body, String error) {
        if (!waiting || !txWifi || token != activeToken) return;
        if (!ok) {
            wifiState = 2;
            endTransaction(PH_ERR, "به کنترلر وصل نشد. مطمئن شوید گوشی به وای‌فای کنترلر وصل است."
                    + (techDetails() && error != null ? " (" + error + ")" : ""));
            return;
        }
        wifiState = 1;
        cmdSmsSent = true;
        if (cmdPhase == PH_SENDING) cmdPhase = PH_WAITING;
        String clean = body == null ? "" : body.trim();
        if (clean.isEmpty()) {
            endTransaction(PH_ERR, "کنترلر پاسخی نفرستاد.");
            return;
        }
        processReply(clean);
    }

    private void armTimeout(long token) {
        handler.postDelayed(() -> {
            if (!waiting || activeToken != token) return;
            String oldType = expectedType;
            int oldIndex = expectedIndex;
            if ("RELAY".equals(oldType) && oldIndex >= 0 && oldIndex < MAX_COILS) coilState[oldIndex] = -1;
            if ("STATUS".equals(oldType)) Arrays.fill(coilState, -1);
            if ("VARS".equals(oldType)) for (int i = 0; i < MAX_REGS; i++) regKnown[i] = false;
            endTransaction(PH_TIMEOUT, txWifi
                    ? "کنترلر پاسخ نداد. مطمئن شوید گوشی به وای‌فای کنترلر وصل است."
                    : "تا ۹۰ ثانیه پاسخی نرسید. برای جلوگیری از اجرای تکراری، فرمان دوباره ارسال نشد؛ وضعیت را رفرش کنید.");
        }, timeoutMs());
    }

    private void queueVarsAfterStatus() {
        // Keep the UI locked across both phases of a refresh transaction.
        expectedType = "VARS";
        expectedIndex = -1;
        pendingCommand = "VARS";
        activeToken = nextToken();
        final long token = activeToken;
        cmdCode = "STATUS ← VARS";
        cmdNote = "✓ وضعیت رله‌ها دریافت شد؛ در حال دریافت رجیسترها…";
        cmdSmsSent = false;
        cmdGotReply = false;
        cmdPhase = PH_SENDING;
        cmdPhaseStart = System.currentTimeMillis();
        stateMessage = "وضعیت رله‌ها دریافت شد؛ در حال دریافت مقدار رجیسترها...";
        armTimeout(token);
        render(false);
        updateSheet();
        handler.postDelayed(() -> {
            if (waiting && activeToken == token) transmit("VARS", token);
        }, 650L);
    }

    private void queueAdminNumber() {
        final String body = "*" + pendingAdminPhone + "*";
        expectedType = "ADMIN_NUM";
        expectedIndex = -1;
        pendingCommand = body;
        activeToken = nextToken();
        final long token = activeToken;
        cmdCode = body;
        cmdNote = "✓ کنترلر شمارهٔ مقصد را خواست؛ در حال ارسال شماره…";
        cmdSmsSent = false;
        cmdGotReply = false;
        cmdPhase = PH_SENDING;
        cmdPhaseStart = System.currentTimeMillis();
        stateMessage = "کنترلر شمارهٔ مقصد را خواست؛ شماره در حال ارسال است...";
        armTimeout(token);
        render(false);
        updateSheet();
        handler.postDelayed(() -> {
            if (waiting && activeToken == token) transmit(body, token);
        }, 650L);
    }

    private void endTransaction(int phase, String message) {
        waiting = false;
        expectedType = "";
        expectedIndex = -1;
        pendingCommand = "";
        pendingAdminPhone = "";
        activeToken = nextToken(); // invalidates old timeout and send callbacks
        cmdPhase = phase;
        cmdResult = message;
        cmdNote = "";
        stateMessage = message;
        handler.removeCallbacks(ticker);
        boolean sheetOpen = sheet != null && sheet.isShowing();
        updateSheet();
        if (!sheetOpen) toast(message);
        if (root != null) {
            int haptic;
            if (phase == PH_OK) haptic = Build.VERSION.SDK_INT >= 30 ? HapticFeedbackConstants.CONFIRM : HapticFeedbackConstants.VIRTUAL_KEY;
            else haptic = Build.VERSION.SDK_INT >= 30 ? HapticFeedbackConstants.REJECT : HapticFeedbackConstants.LONG_PRESS;
            root.performHapticFeedback(haptic);
        }
        render(false);
    }

    private long nextToken() {
        tokenCounter = Math.max(System.currentTimeMillis(), tokenCounter + 1L);
        return tokenCounter;
    }

    // ---------------------------------------------------------------- replies (SMS or Wi-Fi)

    private void processStoredSmsIfNew() {
        long id = smsStore.getLong("last_id", 0L);
        if (id <= prefs.getLong("last_processed_sms_id", 0L)) return;
        handleIncomingOnce(smsStore.getString("last_sender", ""), smsStore.getString("last_body", ""), id);
    }

    private void handleIncomingOnce(String sender, String body, long id) {
        if (id <= 0L || id <= prefs.getLong("last_processed_sms_id", 0L)) return;
        prefs.edit().putLong("last_processed_sms_id", id).apply();
        if (sender == null || body == null) return;
        String configured = normalizePhone(deviceNumber());
        String incoming = normalizePhone(sender);
        if (configured.isEmpty() || !configured.equals(incoming)) {
            // Incoming messages from other senders are intentionally not shown as controller feedback.
            return;
        }
        processReply(body.trim());
    }

    /** Handles one reply from the controller, whether it arrived by SMS or over Wi-Fi. */
    private void processReply(String cleanBody) {
        lastReply = cleanBody;
        prefs.edit().putString("last_reply", lastReply).putLong("last_reply_at", System.currentTimeMillis()).apply();

        int coilUpdates = parseCoilStates(cleanBody);
        int regUpdates = parseRegisterValues(cleanBody);
        String low = cleanBody.toLowerCase(Locale.ROOT);
        if (low.contains("power restored")) {
            stateMessage = "کنترلر دوباره روشن شد.";
            render(false);
            return;
        }

        if (waiting) {
            cmdGotReply = true;
            cmdReply = cleanBody;
            if ("STATUS".equals(expectedType)) {
                if (coilUpdates > 0 && (low.contains("coils:") ||
                        Pattern.compile("(?i)\\b\\d+\\s*:\\s*(ON|OFF|PULSE)").matcher(cleanBody).find())) {
                    if (regsEnabled()) queueVarsAfterStatus();
                    else endTransaction(PH_OK, "وضعیت رله‌ها دریافت و به‌روز شد.");
                    return;
                } else if (isControllerError(cleanBody)) {
                    endTransaction(PH_ERR, "کنترلر پاسخ خطا داد.");
                    return;
                }
            } else if ("VARS".equals(expectedType)) {
                if (regUpdates > 0) {
                    endTransaction(PH_OK, "وضعیت رله‌ها و مقدار رجیسترها به‌روز شد.");
                    return;
                } else if (isControllerError(cleanBody)) {
                    endTransaction(PH_ERR, "کنترلر پاسخ خطا داد.");
                    return;
                }
            } else if ("RELAY".equals(expectedType)) {
                if (containsSingleCoilResponse(cleanBody, expectedIndex + 1)) {
                    int st = coilState[expectedIndex];
                    String what = st == 1 ? "روشن شد" : st == 0 ? "خاموش شد" : "فرمان اجرا شد";
                    endTransaction(PH_OK, "«" + coilNames[expectedIndex] + "» " + what + ".");
                    return;
                } else if (isControllerError(cleanBody)) {
                    endTransaction(PH_ERR, "کنترلر فرمان را نپذیرفت.");
                    return;
                }
            } else if ("REGWRITE".equals(expectedType)) {
                if (containsSingleRegResponse(cleanBody, expectedIndex + 1)) {
                    endTransaction(PH_OK, "مقدار «" + regNames[expectedIndex] + "» ثبت شد: " + regValue[expectedIndex]);
                    return;
                } else if (isControllerError(cleanBody)) {
                    endTransaction(PH_ERR, "کنترلر مقدار را نپذیرفت.");
                    return;
                }
            } else if ("PULSE_CMD".equals(expectedType)) {
                Pattern pulseReply = Pattern.compile("(?i)\\bPulse\\s+on\\s+coil\\s+" + (expectedIndex + 1) + "\\b");
                if (pulseReply.matcher(cleanBody).find()) {
                    endTransaction(PH_OK, "«" + coilNames[expectedIndex] + "» یک لحظه فعال شد.");
                    return;
                } else if (isControllerError(cleanBody)) {
                    endTransaction(PH_ERR, "کنترلر فرمان لحظه‌ای را نپذیرفت. شاید این رله در کنترلر روی حالت «ثابت» تنظیم شده است.");
                    return;
                }
            } else if ("ADMIN".equals(expectedType)) {
                if (low.contains("enter number with *")) {
                    if (!pendingAdminPhone.isEmpty()) queueAdminNumber();
                    else endTransaction(PH_ERR, "شمارهٔ مقصد ثبت نشده بود؛ دوباره تلاش کنید.");
                    return;
                }
                if (isControllerError(cleanBody)) endTransaction(PH_ERR, "کنترلر فرمان را نپذیرفت.");
                else endTransaction(PH_OK, "فرمان انجام شد.");
                return;
            } else if ("ADMIN_NUM".equals(expectedType)) {
                if (isControllerError(cleanBody)) endTransaction(PH_ERR, "کنترلر شماره را نپذیرفت.");
                else endTransaction(PH_OK, "عملیات انجام شد.");
                return;
            }
        }

        if (coilUpdates > 0 || regUpdates > 0) stateMessage = "پیام کنترلر دریافت شد؛ وضعیت به‌روز شد.";
        else stateMessage = "پیامی از کنترلر دریافت شد.";
        updateSheet();
        render(false);
    }

    private int parseCoilStates(String body) {
        int updates = 0;
        Pattern statusList = Pattern.compile("(?i)\\b(\\d{1,2})\\s*:\\s*(ON|OFF|PULSE)\\b");
        Matcher listMatcher = statusList.matcher(body);
        while (listMatcher.find()) {
            int number = parseInt(listMatcher.group(1), -1);
            int state = coilStateFrom(listMatcher.group(2));
            if (number >= 1 && number <= MAX_COILS && state >= 0) {
                coilState[number - 1] = state;
                updates++;
            }
        }
        Pattern single = Pattern.compile("(?i)\\bCoil\\s+(\\d{1,2})\\s*=\\s*(ON|OFF|PULSE)\\b");
        Matcher singleMatcher = single.matcher(body);
        while (singleMatcher.find()) {
            int number = parseInt(singleMatcher.group(1), -1);
            int state = coilStateFrom(singleMatcher.group(2));
            if (number >= 1 && number <= MAX_COILS && state >= 0) {
                coilState[number - 1] = state;
                updates++;
            }
        }
        return updates;
    }

    private int parseRegisterValues(String body) {
        int updates = 0;
        Pattern list = Pattern.compile("(?i)\\bR\\s*(\\d{1,2})\\s*:\\s*(-?\\d+)");
        Matcher m = list.matcher(body);
        while (m.find()) {
            int number = parseInt(m.group(1), -1);
            int value = parseInt(m.group(2), -1);
            if (number >= 1 && number <= MAX_REGS && value >= 0 && value <= 65535) {
                regValue[number - 1] = value;
                regKnown[number - 1] = true;
                updates++;
            }
        }
        Pattern single = Pattern.compile("(?i)\\bReg\\s*(\\d{1,2})\\s*=\\s*(-?\\d+)");
        Matcher sm = single.matcher(body);
        while (sm.find()) {
            int number = parseInt(sm.group(1), -1);
            int value = parseInt(sm.group(2), -1);
            if (number >= 1 && number <= MAX_REGS && value >= 0 && value <= 65535) {
                regValue[number - 1] = value;
                regKnown[number - 1] = true;
                updates++;
            }
        }
        return updates;
    }

    private boolean containsSingleCoilResponse(String body, int number) {
        Pattern p = Pattern.compile("(?i)\\bCoil\\s+" + number + "\\s*=\\s*(ON|OFF|PULSE)\\b");
        return p.matcher(body).find();
    }

    private boolean containsSingleRegResponse(String body, int number) {
        Pattern p = Pattern.compile("(?i)\\bReg\\s*" + number + "\\s*=\\s*-?\\d+");
        return p.matcher(body).find();
    }

    private boolean isControllerError(String body) {
        String low = body.toLowerCase(Locale.ROOT);
        return low.contains("access denied") || low.contains("admin only") || low.contains("invalid") ||
                low.contains("usage:") || low.contains("user not found") || low.contains("not registered") ||
                low.contains("failed") || low.contains("all invite slots full") || low.contains("user exists or full");
    }

    private int coilStateFrom(String state) {
        if (state == null) return -1;
        if (state.equalsIgnoreCase("ON")) return 1;
        if (state.equalsIgnoreCase("OFF")) return 0;
        if (state.equalsIgnoreCase("PULSE")) return 2;
        return -1;
    }

    private int parseInt(String value, int fallback) {
        try { return Integer.parseInt(value.trim()); } catch (Exception ex) { return fallback; }
    }

    private String normalizePhone(String raw) {
        if (raw == null) return "";
        StringBuilder digits = new StringBuilder();
        for (int i = 0; i < raw.length(); i++) {
            char c = raw.charAt(i);
            int d = Character.digit(c, 10);
            if (d >= 0) digits.append((char) ('0' + d));
        }
        String value = digits.toString();
        if (value.startsWith("0098")) value = value.substring(2);
        else if (value.startsWith("0")) value = "98" + value.substring(1);
        else if (value.startsWith("9") && value.length() == 10) value = "98" + value;
        return value;
    }

    // ---------------------------------------------------------------- small UI helpers

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private String safeMessage(Exception ex) {
        String message = ex.getMessage();
        if (message == null || message.trim().isEmpty()) return ex.getClass().getSimpleName();
        return message;
    }

    private void setEnabledLook(View v, boolean enabled) {
        v.setEnabled(enabled);
        v.setAlpha(enabled ? 1f : 0.45f);
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(12), dp(12), dp(12), dp(12));
        c.setBackground(round(CARD, 15, BORDER));
        return c;
    }

    private LinearLayout sectionTitle(String title, String detail) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.HORIZONTAL);
        wrap.setGravity(Gravity.CENTER_VERTICAL);
        wrap.addView(text(title, 17, TEXT, true), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        wrap.addView(text(detail, 11, MUTED, true));
        wrap.setPadding(dp(2), dp(4), dp(2), dp(12));
        return wrap;
    }

    private void addSectionTitle(String title, String detail) {
        contentHost.addView(sectionTitle(title, detail));
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(size);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setGravity(Gravity.CENTER_VERTICAL);
        v.setLineSpacing(dp(2), 1.0f);
        return v;
    }

    private Button button(String label, int background, int foreground) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(13);
        b.setTextColor(foreground);
        b.setAllCaps(false);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(10), dp(5), dp(10), dp(5));
        b.setBackground(round(background, 11, background == CARD_DARK ? BORDER : background));
        if (Build.VERSION.SDK_INT >= 21) b.setStateListAnimator(null);
        return b;
    }

    private GradientDrawable round(int color, int radiusDp, int strokeColor) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(color);
        gd.setCornerRadius(dp(radiusDp));
        gd.setStroke(dp(1), strokeColor);
        return gd;
    }

    private LinearLayout.LayoutParams lpMatchWrap(int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return lp;
    }

    /** Full-width, fixed-height layout params (height in dp). */
    private LinearLayout.LayoutParams lp(int heightDp, int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(heightDp));
        lp.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return lp;
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
